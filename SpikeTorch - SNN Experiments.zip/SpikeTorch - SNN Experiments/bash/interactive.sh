srun --pty --mem 8000 --partition titanx-short --gres gpu:1 -t 0-01:00 /bin/bash
