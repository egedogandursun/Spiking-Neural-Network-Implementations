\mainpage AurynDoc Mainpage

This Doxygen generated static web page contains detailed information on the API and usage of Auryn classes.

High-level documentation and examples are maintained separately in the wiki at
https://fzenke.net/auryn/

