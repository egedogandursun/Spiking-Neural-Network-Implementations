# Auryn Python toolkit

This code allows you to efficiently import spikes 
written by BinarySpikeMonitor into Python.

To use auryntools as a python package point your PythonPath to this directory. For instance by:
```
export PYTHONPATH=$PYTHONPATH:<path_to_this_directory>/auryn/tools/python
```

See http://www.fzenke.net/auryn/doku.php?id=manual:python_binary_toolkit 
for examples.
